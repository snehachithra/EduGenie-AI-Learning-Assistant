from gemini_client import generate_text


def get_learning_recommendations(topic: str) -> str:
    topic = topic.strip()
    if not topic:
        raise ValueError("Topic cannot be empty.")

    prompt = f"""
Create a personalized learning path for: {topic}

Organize it from beginner to advanced. Include:
1. Prerequisites
2. Beginner concepts
3. Intermediate concepts
4. Advanced concepts
5. A practical mini-project or activity
6. Suggested resource types (videos, articles, books, documentation)
7. A simple suggested timeline

Keep the plan actionable and suitable for a learner starting from the basics.
"""

    return generate_text(
        prompt,
        system_instruction=(
            "You are an educational curriculum planner. "
            "Adapt the learning path to the learner's likely level and keep it practical."
        ),
        temperature=0.4,
        max_output_tokens=1400,
    )
