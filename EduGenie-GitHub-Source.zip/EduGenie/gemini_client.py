import os
from functools import lru_cache

from dotenv import load_dotenv
from google import genai

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3-flash")

if not GEMINI_API_KEY:
    # The client is created lazily so the app can still start and show a useful
    # configuration error rather than failing during module import.
    _client = None
else:
    _client = genai.Client(api_key=GEMINI_API_KEY)


def generate_text(prompt: str, *, system_instruction: str | None = None,
                  temperature: float = 0.4, max_output_tokens: int = 1200) -> str:
    if _client is None:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured. Copy .env.example to .env and add your key."
        )

    config = {
        "temperature": temperature,
        "max_output_tokens": max_output_tokens,
    }
    if system_instruction:
        config["system_instruction"] = system_instruction

    response = _client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=config,
    )
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()
