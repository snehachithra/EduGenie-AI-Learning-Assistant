from quiz_module import clean_json_block


def test_clean_json_block():
    raw = """```json
    [{"question": "2+2?", "options": ["1", "2", "3", "4"], "answer": "4"}]
    ```"""
    assert clean_json_block(raw).startswith("[")
    assert clean_json_block(raw).endswith("]")


def test_clean_plain_json():
    raw = '[{"question":"Q","options":["A","B","C","D"],"answer":"A"}]'
    assert clean_json_block(raw) == raw
