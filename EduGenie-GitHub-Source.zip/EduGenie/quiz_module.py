import json
import re

from gemini_client import generate_text


def clean_json_block(text: str) -> str:
    """Remove Markdown fences and isolate the JSON object/array."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    start_candidates = [i for i in (text.find("["), text.find("{")) if i >= 0]
    if start_candidates:
        start = min(start_candidates)
        end = max(text.rfind("]"), text.rfind("}"))
        if end >= start:
            text = text[start:end + 1]
    return text.strip()


def _validate_quiz(data):
    if not isinstance(data, list) or len(data) != 3:
        raise ValueError("Quiz must contain exactly 3 questions.")

    cleaned = []
    for item in data:
        if not isinstance(item, dict):
            raise ValueError("Each quiz question must be an object.")

        question = str(item.get("question", "")).strip()
        options = item.get("options", [])
        answer = str(item.get("answer", "")).strip()

        if not question or not isinstance(options, list) or len(options) != 4:
            raise ValueError("Each question must have 4 options.")
        if answer not in [str(x) for x in options]:
            raise ValueError("The correct answer must match one option.")

        cleaned.append({
            "question": question,
            "options": [str(x) for x in options],
            "answer": answer,
        })
    return cleaned


def generate_quiz(passage: str):
    passage = passage.strip()
    if not passage:
        raise ValueError("Passage cannot be empty.")

    prompt = f"""
Create exactly 3 multiple-choice questions from the educational passage below.

Return ONLY valid JSON, with this exact shape:
[
  {{
    "question": "Question text",
    "options": ["A", "B", "C", "D"],
    "answer": "The exact correct option text"
  }}
]

Make the questions relevant to the passage and make the distractors plausible.

PASSAGE:
{passage}
"""

    raw = generate_text(
        prompt,
        system_instruction="You generate reliable educational MCQs in strict JSON.",
        temperature=0.3,
        max_output_tokens=1200,
    )

    try:
        return _validate_quiz(json.loads(clean_json_block(raw)))
    except (json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"Quiz generation/parsing failed: {exc}") from exc
