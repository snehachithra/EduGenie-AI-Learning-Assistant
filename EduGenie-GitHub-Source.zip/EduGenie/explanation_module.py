import os
from functools import lru_cache

from gemini_client import generate_text

USE_LOCAL_EXPLAINER = os.getenv("USE_LOCAL_EXPLAINER", "false").lower() == "true"


@lru_cache(maxsize=1)
def _load_local_model():
    """Load LaMini-Flan-T5 only when explicitly enabled.

    The model is intentionally lazy because downloading/loading a transformer
    can take significant disk space and memory.
    """
    from transformers import pipeline
    return pipeline(
        "text2text-generation",
        model="MBZUAI/LaMini-Flan-T5-783M",
    )


def _local_explain(topic: str) -> str:
    generator = _load_local_model()
    prompt = (
        "Explain the following topic to a beginner in simple language. "
        "Use short paragraphs and one small example.\n\n"
        f"Topic: {topic}"
    )
    result = generator(prompt, max_new_tokens=250, do_sample=False)
    return result[0]["generated_text"].strip()


def explain_topic(topic: str) -> str:
    topic = topic.strip()
    if not topic:
        raise ValueError("Topic cannot be empty.")

    if USE_LOCAL_EXPLAINER:
        try:
            return _local_explain(topic)
        except Exception:
            # Fall back to Gemini if the optional local model is unavailable.
            pass

    return generate_text(
        f"Explain this educational topic for a beginner:\n\n{topic}",
        system_instruction=(
            "You are EduGenie, an educational assistant. "
            "Be concise, accurate, friendly, and easy to understand."
        ),
        temperature=0.3,
        max_output_tokens=700,
    )
