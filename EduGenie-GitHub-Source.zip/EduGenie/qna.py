from gemini_client import generate_text


def answer_question(question: str) -> str:
    question = question.strip()
    if not question:
        raise ValueError("Question cannot be empty.")

    return generate_text(
        question,
        system_instruction=(
            "You are EduGenie, a helpful academic question-answering assistant. "
            "Answer directly, explain reasoning when useful, and avoid unnecessary verbosity."
        ),
        temperature=0.2,
        max_output_tokens=900,
    )
