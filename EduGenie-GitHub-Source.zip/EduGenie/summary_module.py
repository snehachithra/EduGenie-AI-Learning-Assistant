from gemini_client import generate_text


def summarize_text(text: str) -> str:
    text = text.strip()
    if not text:
        raise ValueError("Text cannot be empty.")

    return generate_text(
        f"Summarize the following educational text into concise revision notes. "
        f"Retain the important facts and context.\n\n{text}",
        system_instruction="You are EduGenie. Produce clear, concise study summaries.",
        temperature=0.2,
        max_output_tokens=900,
    )
