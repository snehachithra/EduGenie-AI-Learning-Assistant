# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight AI-powered educational assistant based on the supplied project specification. It provides:

- Question answering
- Simplified explanations
- 3-question MCQ generation
- Educational passage summarization
- Personalized beginner-to-advanced learning paths

The architecture uses FastAPI for the backend and HTML/CSS/JavaScript for the frontend.

## Project structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_quiz_module.py
```

## Requirements

- Python 3.10+
- A Gemini API key
- Internet access for Gemini API calls
- Optional: enough RAM/disk for the local LaMini-Flan-T5 model

## Setup

### 1. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and add your Gemini API key:

```env
GEMINI_API_KEY=your_real_key
GEMINI_MODEL=gemini-3-flash
```

Do not commit `.env` to GitHub.

### 4. Run

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/qa` | Question answering |
| POST | `/explain` | Explain a concept |
| POST | `/quiz` | Generate exactly 3 MCQs |
| POST | `/summarize` | Summarize educational text |
| POST | `/learn/recommendations` | Generate a learning path |

Interactive API documentation is available at:

```text
http://127.0.0.1:8000/docs
```

## Optional local explanation model

The original project specification uses `LaMini-Flan-T5-783M` for concept explanations. This implementation supports that model through:

```env
USE_LOCAL_EXPLAINER=true
```

The model is loaded lazily. If it cannot be loaded, the explanation module falls back to Gemini.

## GitHub

Create a repository named `EduGenie`, then:

```bash
git init
git add .
git commit -m "Initial EduGenie learning assistant"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/EduGenie.git
git push -u origin main
```

## Notes

The original document names Gemini 1.5 Pro. Google now recommends the newer `google-genai` SDK for Gemini API access, so the code uses that SDK and makes the model configurable through `GEMINI_MODEL`.

Never place API keys directly in source code or commit them to GitHub.
